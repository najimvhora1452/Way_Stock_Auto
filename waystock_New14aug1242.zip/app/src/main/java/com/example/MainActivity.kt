package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.WayStockViewModel
import com.example.ui.screens.MainInventoryScreen
import com.example.ui.theme.WayStockTheme

class MainActivity : ComponentActivity() {
    private val viewModel: WayStockViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WayStockTheme {
                MainInventoryScreen(viewModel = viewModel)
            }
        }
    }
}
