package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.WayStockViewModel
import com.example.ui.components.*
import com.example.ui.dialogs.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainInventoryScreen(viewModel: WayStockViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val allInventoryItems by viewModel.allInventoryItems.collectAsState()
    val cartItems by viewModel.cartItems.collectAsState()
    val searchHistory by viewModel.searchHistory.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    // Handle Android system back gesture and back button gracefully
    val isAnyOverlayOrNestedOpen = uiState.isSelectionMode ||
            uiState.isSearchOpen ||
            uiState.isOrderSlipOpen ||
            uiState.isCartOpen ||
            uiState.isAdminSettingsOpen ||
            uiState.isAdminGatewayOpen ||
            uiState.isAddModalOpen ||
            uiState.isShareAppOpen ||
            uiState.pathStack.size > 1

    BackHandler(enabled = isAnyOverlayOrNestedOpen) {
        focusManager.clearFocus()
        keyboardController?.hide()
        when {
            uiState.isSelectionMode -> viewModel.clearCardSelection()
            uiState.isSearchOpen -> viewModel.setSearchOpen(false)
            uiState.isOrderSlipOpen -> viewModel.setOrderSlipOpen(false)
            uiState.isCartOpen -> viewModel.setCartOpen(false)
            uiState.isAdminSettingsOpen -> viewModel.setAdminSettingsOpen(false)
            uiState.isAdminGatewayOpen -> viewModel.setAdminGatewayOpen(false)
            uiState.isAddModalOpen -> viewModel.setAddModalOpen(false)
            uiState.isShareAppOpen -> viewModel.setShareAppOpen(false)
            uiState.pathStack.size > 1 -> viewModel.jumpToBreadcrumb(uiState.pathStack.size - 2)
        }
    }

    // Show alert messages in snackbar
    LaunchedEffect(uiState.alertMessage) {
        uiState.alertMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearAlert()
        }
    }

    // Filter items in current folder
    val currentItems = remember(allInventoryItems, uiState.currentFolder) {
        allInventoryItems.filter { it.parent == uiState.currentFolder }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column {
                if (uiState.isSelectionMode) {
                    // Selection Action Bar
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .testTag("selection_toolbar"),
                        color = Color.White,
                        shadowElevation = 4.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { viewModel.clearCardSelection() },
                                    modifier = Modifier.testTag("cancel_selection_btn")
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = WayStockTextSec)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${uiState.selectedCardKeys.size} Selected",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = WayStockDark
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                val isAllSelected = uiState.selectedCardKeys.size == currentItems.size && currentItems.isNotEmpty()
                                IconButton(
                                    onClick = {
                                        if (isAllSelected) viewModel.clearCardSelection()
                                        else viewModel.selectAllInCurrentFolder(currentItems)
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.SelectAll,
                                        contentDescription = "Select All",
                                        tint = WayStockPrimary
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.bulkAddToCartSelected() }
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.ShoppingCart,
                                        contentDescription = "Bulk Add to Cart",
                                        tint = WayStockPrimary
                                    )
                                }

                                if (uiState.selectedCardKeys.size == 1) {
                                    val singleKey = uiState.selectedCardKeys.first()
                                    IconButton(
                                        onClick = {
                                            viewModel.setAddModalOpen(true, editKey = singleKey)
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Edit,
                                            contentDescription = "Edit Name",
                                            tint = WayStockPrimary
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { viewModel.bulkDeleteSelected() }
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Delete,
                                        contentDescription = "Delete Selected",
                                        tint = WayStockDanger
                                    )
                                }
                            }
                        }
                    }
                } else {
                    HeaderBar(
                        userName = uiState.userName,
                        isAdminMode = uiState.isAdminMode,
                        cartItemCount = cartItems.size,
                        onSearchClick = { viewModel.setSearchOpen(true) },
                        onCartClick = { viewModel.setCartOpen(true) },
                        onAddStructureClick = { viewModel.setAddModalOpen(true) },
                        onAdminSettingsClick = { viewModel.setAdminSettingsOpen(true) },
                        onShareAppClick = { viewModel.setShareAppOpen(true) },
                        onAdminLogoutClick = { viewModel.logoutAdmin() }
                    )
                }

                BreadcrumbBar(
                    pathStack = uiState.pathStack,
                    onBreadcrumbClick = { index -> viewModel.jumpToBreadcrumb(index) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(WayStockBg)
        ) {
            if (currentItems.isEmpty()) {
                // Empty State
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("📦✨", fontSize = 50.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Oho! Maal-Gadi Khali Hai",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = WayStockDark
                    )
                    Text(
                        text = "Lagta hai abhi tak koi stock nahi aaya. Chalo, kuch naya bharte hain!",
                        fontSize = 13.sp,
                        color = WayStockTextSec,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 6.dp, bottom = 24.dp)
                    )

                    Button(
                        onClick = {
                            if (uiState.isAdminMode) {
                                viewModel.setAddModalOpen(true)
                            } else {
                                viewModel.setCartOpen(true)
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = WayStockPrimary)
                    ) {
                        Text(
                            text = if (uiState.isAdminMode) "Maal Bharo! 🚀" else "Bucket Dekho! 🛒",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(currentItems, key = { it.key }) { item ->
                        val cartItem = cartItems.find { it.key == item.key }
                        val cartQty = cartItem?.quantity ?: 0
                        val cartUnit = cartItem?.unit ?: item.currentUnit
                        val isSelected = uiState.selectedCardKeys.contains(item.key)

                        InventoryCard(
                            item = item,
                            cartQuantity = cartQty,
                            cartUnit = cartUnit,
                            isAdminMode = uiState.isAdminMode,
                            isSelected = isSelected,
                            isSelectionMode = uiState.isSelectionMode,
                            onCardClick = {
                                if (item.type == "folder") {
                                    viewModel.navigateFolder(item.key)
                                }
                            },
                            onCardLongClick = {
                                viewModel.toggleCardSelection(item.key)
                            },
                            onAddToCart = { viewModel.addToCart(item.key) },
                            onUpdateQuantity = { change ->
                                viewModel.updateCartQuantity(item.key, change)
                            },
                            onFolderToggleChange = { isChecked ->
                                viewModel.toggleFolderPrefix(item.key, isChecked)
                            },
                            onAddSubItemClick = {
                                viewModel.openAddSubItemModal(item.key)
                            },
                            onUnitSelected = { newUnit ->
                                if (cartQty > 0) {
                                    viewModel.updateCartUnit(item.key, newUnit)
                                }
                            },
                            onAddCustomUnit = { unitName ->
                                viewModel.addCustomUnitToCategoryTree(item.key, unitName)
                            },
                            onDeleteCustomUnit = { unitName ->
                                viewModel.deleteCustomUnitFromCategoryTree(item.key, unitName)
                            }
                        )
                    }
                }
            }
        }
    }

        // Full-screen Search Overlay (covers entire page 100% on top of topBar, menu, cart)
        if (uiState.isSearchOpen) {
            SearchOverlay(
                allInventoryItems = allInventoryItems,
                cartItems = cartItems,
                searchHistory = searchHistory,
                onDismiss = { viewModel.setSearchOpen(false) },
                onSuggestionClick = { key ->
                    viewModel.navigateFolder(key)
                    viewModel.setSearchOpen(false)
                },
                onAddToCart = { key -> viewModel.addToCart(key) },
                onVoiceCommand = { cmd -> viewModel.handleVoiceCommand(cmd) }
            )
        }

        // Onboarding Dialog
        if (!uiState.isOnboarded) {
            UserOnboardingDialog(
                onNameSubmitted = { name -> viewModel.setUserProfile(name) }
            )
        }

        // Admin Gateway PIN Modal
        if (uiState.isAdminGatewayOpen) {
            AdminGatewayDialog(
                onDismiss = { viewModel.setAdminGatewayOpen(false) },
                onValidatePin = { pin -> viewModel.validateAdminPin(pin) }
            )
        }

        // Bulk Add / Excel Structure Modal
        if (uiState.isAddModalOpen) {
            BulkAddModal(
                currentParentFolder = uiState.addModalTargetFolder ?: uiState.currentFolder,
                editTargetKey = uiState.editTargetKey,
                allExistingItems = allInventoryItems,
                onDismiss = { viewModel.setAddModalOpen(false) },
                onSubmitStructure = { text -> viewModel.processBulkStructure(text) }
            )
        }

        // Cart Sheet ("My Bucket")
        if (uiState.isCartOpen) {
            CartSheet(
                cartItems = cartItems,
                allInventoryItems = allInventoryItems,
                isAdminMode = uiState.isAdminMode,
                onDismiss = { viewModel.setCartOpen(false) },
                onUpdateQuantity = { key, change -> viewModel.updateCartQuantity(key, change) },
                onSetQuantityDirectly = { key, qty -> viewModel.setCartQuantityDirectly(key, qty) },
                onUpdateUnit = { key, unit -> viewModel.updateCartUnit(key, unit) },
                onRemoveItem = { key -> viewModel.removeFromCart(key) },
                onGeneratePreview = { viewModel.setOrderSlipOpen(true) },
                onAddCustomUnit = { key, unit -> viewModel.addCustomUnitToCategoryTree(key, unit) },
                onDeleteCustomUnit = { key, unit -> viewModel.deleteCustomUnitFromCategoryTree(key, unit) }
            )
        }

        // Order Slip Preview Dialog
        if (uiState.isOrderSlipOpen) {
            OrderSlipPreviewDialog(
                cartItems = cartItems,
                inventoryItems = allInventoryItems,
                onDismiss = { viewModel.setOrderSlipOpen(false) },
                onSlipSavedOrShared = { keysToFlush ->
                    keysToFlush.forEach { key -> viewModel.removeFromCart(key) }
                    viewModel.showAlert("✅ Order Slip processed! Items cleared from Bucket.", "success")
                    if (cartItems.size <= keysToFlush.size) {
                        viewModel.setOrderSlipOpen(false)
                    }
                }
            )
        }

        // Admin Settings Dialog
        if (uiState.isAdminSettingsOpen) {
            AdminSettingsDialog(
                onDismiss = { viewModel.setAdminSettingsOpen(false) },
                onUpdatePassword = { oldPin, newPin -> viewModel.updateAdminPassword(oldPin, newPin) },
                onSendBroadcast = { msg -> viewModel.sendBroadcastNotification(msg) },
                onLogoutAdmin = { viewModel.logoutAdmin() }
            )
        }

        // Share App QR Card Dialog
        if (uiState.isShareAppOpen) {
            ShareAppCardDialog(
                onDismiss = { viewModel.setShareAppOpen(false) }
            )
        }
    }
}
