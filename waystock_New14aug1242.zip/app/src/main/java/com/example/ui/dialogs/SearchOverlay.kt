package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CartItemEntity
import com.example.data.InventoryItemEntity
import com.example.data.SearchHistoryEntity
import com.example.ui.theme.*

@Composable
fun SearchOverlay(
    allInventoryItems: List<InventoryItemEntity>,
    cartItems: List<CartItemEntity>,
    searchHistory: List<SearchHistoryEntity>,
    onDismiss: () -> Unit,
    onSuggestionClick: (String) -> Unit,
    onAddToCart: (String) -> Unit,
    onVoiceCommand: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var isListeningVoice by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    val filteredMatches = remember(searchQuery, allInventoryItems) {
        if (searchQuery.isBlank()) emptyList()
        else {
            val q = searchQuery.trim().lowercase()
            allInventoryItems.filter {
                it.name.lowercase().contains(q) || it.key.lowercase().contains(q)
            }.take(10)
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .testTag("search_overlay"),
        color = Color.White
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Search Header Bar
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                color = Color.White,
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            focusManager.clearFocus()
                            keyboardController?.hide()
                            onDismiss()
                        },
                        modifier = Modifier.testTag("search_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = WayStockTextMain
                        )
                    }

                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFF1F5F9)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = WayStockTextSec,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))

                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Search items or type 'admin.html'...", fontSize = 14.sp, color = WayStockTextSec) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(
                                    onSearch = {
                                        focusManager.clearFocus()
                                        keyboardController?.hide()
                                        if (searchQuery.trim().equals("admin.html", ignoreCase = true)) {
                                            onVoiceCommand("admin.html")
                                        }
                                    }
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = WayStockDark,
                                    unfocusedTextColor = WayStockDark,
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("main_search_input")
                            )

                            if (searchQuery.isNotEmpty()) {
                                IconButton(
                                    onClick = { searchQuery = "" },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Clear",
                                        tint = WayStockTextSec,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            // Mic Button for Voice Commands
                            IconButton(
                                onClick = {
                                    isListeningVoice = true
                                },
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("voice_search_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Voice Search",
                                    tint = WayStockPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Results / Suggestions Area
            if (searchQuery.isNotBlank()) {
                if (filteredMatches.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No results found for '$searchQuery'",
                            fontSize = 14.sp,
                            color = WayStockTextSec
                        )
                    }
                } else {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(filteredMatches, key = { it.key }) { item ->
                            val isInCart = cartItems.any { it.key == item.key }
                            val displayPath = if (item.key.contains(">")) {
                                val parts = item.key.split(">")
                                "${parts[parts.size - 2]} > ${item.name}"
                            } else item.name

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        focusManager.clearFocus()
                                        keyboardController?.hide()
                                        if (item.name.lowercase() == "admin.html") {
                                            onVoiceCommand("admin.html")
                                        } else {
                                            onSuggestionClick(item.key)
                                        }
                                    }
                                    .padding(horizontal = 20.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    if (item.type == "folder") {
                                        Icon(
                                            imageVector = Icons.Outlined.Folder,
                                            contentDescription = null,
                                            tint = Color(0xFFF59E0B),
                                            modifier = Modifier.size(22.dp)
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Outlined.Inventory2,
                                            contentDescription = null,
                                            tint = WayStockTealMedium,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))

                                    Column {
                                        Text(
                                            text = displayPath,
                                            fontSize = 14.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = WayStockTextMain,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = if (item.key.contains(">")) item.key else "Root Level",
                                            fontSize = 11.sp,
                                            color = WayStockTextSec
                                        )
                                    }
                                }

                                if (item.type == "item") {
                                    if (isInCart) {
                                        Surface(
                                            color = Color(0xFFECFDF5),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = "✓ Added",
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = WayStockSuccess
                                            )
                                        }
                                    } else {
                                        IconButton(
                                            onClick = { onAddToCart(item.key) },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(Color.White)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.ShoppingCart,
                                                contentDescription = "Add",
                                                tint = WayStockTextSec,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            HorizontalDivider(color = Color(0xFFF1F5F9))
                        }
                    }
                }
            } else {
                // Recent Searches
                if (searchHistory.isNotEmpty()) {
                    Text(
                        text = "⏱️ RECENT SEARCHES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = WayStockTextSec,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF8FAFC))
                            .padding(horizontal = 20.dp, vertical = 10.dp)
                    )

                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(searchHistory, key = { it.id }) { history ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        focusManager.clearFocus()
                                        keyboardController?.hide()
                                        onSuggestionClick(history.itemKey)
                                    }
                                    .padding(horizontal = 20.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    tint = WayStockTextSec,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(
                                    text = history.queryText,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = WayStockTextMain
                                )
                            }
                            HorizontalDivider(color = Color(0xFFF1F5F9))
                        }
                    }
                }
            }
        }

        // Voice Command Simulation Dialog if Mic tapped
        if (isListeningVoice) {
            AlertDialog(
                onDismissRequest = { isListeningVoice = false },
                title = { Text("🎙️ Voice Command", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("Try speaking or tapping a command:", fontSize = 13.sp, color = WayStockTextSec)
                        Spacer(modifier = Modifier.height(12.dp))
                        listOf("open Snacks", "add 2 Lays", "open Paan Masala", "admin.html").forEach { cmd ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        isListeningVoice = false
                                        onVoiceCommand(cmd)
                                    },
                                color = Color(0xFFEFF6FF),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "\"$cmd\"",
                                    modifier = Modifier.padding(10.dp),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = WayStockPrimary
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { isListeningVoice = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
