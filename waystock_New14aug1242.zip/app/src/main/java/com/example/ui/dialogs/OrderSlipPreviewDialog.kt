package com.example.ui.dialogs

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.CartItemEntity
import com.example.data.InventoryItemEntity
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun OrderSlipPreviewDialog(
    cartItems: List<CartItemEntity>,
    inventoryItems: List<InventoryItemEntity>,
    onDismiss: () -> Unit,
    onSlipSavedOrShared: (List<String>) -> Unit
) {
    val context = LocalContext.current
    val currentDate = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date()) }

    // Group cart items by rootFolder
    val groupedCart = remember(cartItems) {
        cartItems.groupBy { it.rootFolder }
    }
    val categories = remember(groupedCart) { groupedCart.keys.toList() }

    // Selected page index for Full-Screen Zoom / Slide View
    var zoomPageIndex by remember { mutableStateOf<Int?>(null) }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .testTag("preview_section"),
        color = WayStockBg
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Bar
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp),
                    color = Color.White,
                    shadowElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = WayStockTextMain)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Order Slips Preview",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = WayStockDark
                            )
                            Text(
                                text = "${categories.size} Category Page${if (categories.size > 1) "s" else ""} • Tap page to enlarge",
                                fontSize = 11.sp,
                                color = WayStockTextSec
                            )
                        }
                    }
                }

                if (groupedCart.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No items in Bucket to preview", color = WayStockDark, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    }
                } else {
                    // 2-by-2 Grid Layout (1st top-left, 2nd top-right, 3rd bottom-left, 4th bottom-right...)
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        itemsIndexed(categories) { index, rootFolder ->
                            val items = groupedCart[rootFolder] ?: emptyList()
                            SlipCardMiniature(
                                rootFolder = rootFolder,
                                items = items,
                                inventoryItems = inventoryItems,
                                pageNumber = index + 1,
                                totalPages = categories.size,
                                currentDate = currentDate,
                                onClick = { zoomPageIndex = index }
                            )
                        }
                    }
                }
            }

            // Fullscreen Zoom Pager Modal (Slide left / right between pages)
            zoomPageIndex?.let { initialIndex ->
                FullScreenSlipPagerModal(
                    categories = categories,
                    groupedCart = groupedCart,
                    inventoryItems = inventoryItems,
                    initialPageIndex = initialIndex,
                    currentDate = currentDate,
                    onDismiss = { zoomPageIndex = null },
                    onSaveOrShare = { keys ->
                        onSlipSavedOrShared(keys)
                    }
                )
            }
        }
    }
}

/**
 * 2x2 Grid Item Card (Compact slip preview)
 */
@Composable
private fun SlipCardMiniature(
    rootFolder: String,
    items: List<CartItemEntity>,
    inventoryItems: List<InventoryItemEntity>,
    pageNumber: Int,
    totalPages: Int,
    currentDate: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(280.dp)
            .shadow(6.dp, RoundedCornerShape(14.dp))
            .border(1.5.dp, WayStockBorder, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag("slip_card_$pageNumber"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
        ) {
            // Card Top Banner
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .background(WayStockPrimary.copy(alpha = 0.12f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "PAGE $pageNumber/$totalPages",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = WayStockPrimaryDark,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Icon(
                    imageVector = Icons.Default.ZoomIn,
                    contentDescription = "Zoom",
                    tint = WayStockPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Category Title
            Text(
                text = rootFolder.uppercase(),
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                color = WayStockDark,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "${items.size} item(s) • $currentDate",
                fontSize = 9.5.sp,
                color = WayStockTextSec,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )

            HorizontalDivider(
                color = WayStockDark,
                thickness = 1.dp,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            // Miniature item preview lines
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items.take(4).forEachIndexed { idx, item ->
                    val parentKey = if (item.fullPath.contains(">")) {
                        item.fullPath.substringBeforeLast(">")
                    } else ""
                    val parentEntity = inventoryItems.find { it.key == parentKey }
                    val displayName = if (parentEntity?.toggleOn == true) {
                        "${parentEntity.name} ${item.name}"
                    } else item.name

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${idx + 1}. $displayName",
                            fontSize = 11.sp,
                            color = WayStockTextMain,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${item.quantity} ${item.unit}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = WayStockDark,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                if (items.size > 4) {
                    Text(
                        text = "+ ${items.size - 4} more items...",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = WayStockPrimary,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            // Tap to view full slip prompt
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = WayStockSelectedBg,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "Tap to Enlarge & Share 👆",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = WayStockPrimaryDark,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
        }
    }
}

/**
 * Fullscreen Slip Pager with horizontal swipe and action buttons
 */
@Composable
private fun FullScreenSlipPagerModal(
    categories: List<String>,
    groupedCart: Map<String, List<CartItemEntity>>,
    inventoryItems: List<InventoryItemEntity>,
    initialPageIndex: Int,
    currentDate: String,
    onDismiss: () -> Unit,
    onSaveOrShare: (List<String>) -> Unit
) {
    val context = LocalContext.current
    val pagerState = rememberPagerState(initialPage = initialPageIndex, pageCount = { categories.size })
    val coroutineScope = rememberCoroutineScope()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Black.copy(alpha = 0.85f)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Control Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.2f), CircleShape)
                            .size(40.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }

                    // Page Indicator pill
                    Box(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Page ${pagerState.currentPage + 1} of ${categories.size}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    // Navigation Chevrons
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = {
                                if (pagerState.currentPage > 0) {
                                    coroutineScope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) }
                                }
                            },
                            enabled = pagerState.currentPage > 0,
                            modifier = Modifier
                                .background(Color.White.copy(alpha = if (pagerState.currentPage > 0) 0.25f else 0.1f), CircleShape)
                                .size(36.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous Page", tint = Color.White)
                        }

                        IconButton(
                            onClick = {
                                if (pagerState.currentPage < categories.size - 1) {
                                    coroutineScope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                                }
                            },
                            enabled = pagerState.currentPage < categories.size - 1,
                            modifier = Modifier
                                .background(Color.White.copy(alpha = if (pagerState.currentPage < categories.size - 1) 0.25f else 0.1f), CircleShape)
                                .size(36.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next Page", tint = Color.White)
                        }
                    }
                }

                // Horizontal Pager for Pages (Left / Right swipe)
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) { page ->
                    val rootFolder = categories[page]
                    val items = groupedCart[rootFolder] ?: emptyList()

                    FullSlipReceiptCard(
                        rootFolder = rootFolder,
                        items = items,
                        inventoryItems = inventoryItems,
                        pageIndex = page,
                        totalPages = categories.size,
                        currentDate = currentDate,
                        onSave = {
                            val keys = items.map { it.key }
                            onSaveOrShare(keys)
                        },
                        onShare = {
                            val keys = items.map { it.key }
                            val slipText = StringBuilder().apply {
                                append("🚨 WAYSTOCK ORDER SLIP: $rootFolder\n")
                                append("Date: $currentDate\n")
                                append("Page: ${page + 1}/${categories.size}\n\n")
                                items.forEachIndexed { i, it ->
                                    append("${i + 1}. ${it.name} - ${it.quantity} ${it.unit}\n")
                                }
                                append("\nGenerated via WayStock App 🚀")
                            }.toString()

                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, slipText)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Order Slip"))
                            onSaveOrShare(keys)
                        }
                    )
                }

                Text(
                    text = "👈 Slide left/right to switch category slips 👉",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                )
            }
        }
    }
}

/**
 * Enriched receipt card shown inside full screen pager
 */
@Composable
private fun FullSlipReceiptCard(
    rootFolder: String,
    items: List<CartItemEntity>,
    inventoryItems: List<InventoryItemEntity>,
    pageIndex: Int,
    totalPages: Int,
    currentDate: String,
    onSave: () -> Unit,
    onShare: () -> Unit
) {
    val scrollState = rememberScrollState()

    Card(
        modifier = Modifier
            .fillMaxSize()
            .shadow(16.dp, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            // Receipt Header
            Text(
                text = rootFolder.uppercase(),
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = WayStockDark,
                fontFamily = FontFamily.Monospace
            )

            Text(
                text = "Total Items: ${items.size} | Page ${pageIndex + 1}/$totalPages | $currentDate",
                fontSize = 11.sp,
                color = WayStockTextSec,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
            )

            HorizontalDivider(color = WayStockDark, thickness = 2.5.dp)
            Spacer(modifier = Modifier.height(10.dp))

            // Scrollable Item List
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(scrollState)
            ) {
                items.forEachIndexed { idx, item ->
                    val parentKey = if (item.fullPath.contains(">")) {
                        item.fullPath.substringBeforeLast(">")
                    } else ""

                    val parentEntity = inventoryItems.find { it.key == parentKey }
                    val displayName = if (parentEntity?.toggleOn == true) {
                        "${parentEntity.name} ${item.name}"
                    } else item.name

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 7.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${idx + 1}. $displayName",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = WayStockTextMain,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1f)
                        )

                        Text(
                            text = "${item.quantity} ${item.unit}",
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = WayStockDark,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    HorizontalDivider(color = WayStockBorder, thickness = 0.8.dp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = WayStockDark, thickness = 1.5.dp)
            Spacer(modifier = Modifier.height(12.dp))

            // Footer with Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "WayStock Master Slip",
                    fontSize = 11.sp,
                    color = WayStockTextSec,
                    fontFamily = FontFamily.Monospace
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onSave,
                        colors = ButtonDefaults.buttonColors(containerColor = WayStockPrimary),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("download_slip_btn")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Button(
                        onClick = onShare,
                        colors = ButtonDefaults.buttonColors(containerColor = WayStockSuccess),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("share_slip_btn")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}
