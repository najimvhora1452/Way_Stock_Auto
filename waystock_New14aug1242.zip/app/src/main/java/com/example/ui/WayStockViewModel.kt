package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CartItemEntity
import com.example.data.InventoryItemEntity
import com.example.data.SearchHistoryEntity
import com.example.data.WayStockRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class WayStockUiState(
    val currentFolder: String = "root",
    val pathStack: List<String> = listOf("root"),
    val userName: String = "",
    val userId: String = "guest",
    val isOnboarded: Boolean = false,
    val isAdminMode: Boolean = false,
    val adminPin: String = "1234",
    val broadcastMessage: String = "",
    val searchQuery: String = "",
    val isSearchOpen: Boolean = false,
    val isCartOpen: Boolean = false,
    val isAddModalOpen: Boolean = false,
    val isAdminSettingsOpen: Boolean = false,
    val isShareAppOpen: Boolean = false,
    val isAdminGatewayOpen: Boolean = false,
    val isOrderSlipOpen: Boolean = false,
    val selectedCardKeys: Set<String> = emptySet(),
    val isSelectionMode: Boolean = false,
    val editTargetKey: String? = null,
    val addModalTargetFolder: String? = null,
    val alertMessage: String? = null,
    val alertType: String = "info"
)

class WayStockViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = WayStockRepository(application)

    private val _uiState = MutableStateFlow(WayStockUiState())
    val uiState: StateFlow<WayStockUiState> = _uiState.asStateFlow()

    val allInventoryItems: StateFlow<List<InventoryItemEntity>> = repository.allInventoryItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartItems: StateFlow<List<CartItemEntity>> = _uiState.flatMapLatest { state ->
        repository.getCartItems(state.userId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchHistory: StateFlow<List<SearchHistoryEntity>> = _uiState.flatMapLatest { state ->
        repository.getSearchHistory(state.userId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
            syncFolderAndItemTypes()
        }
    }

    suspend fun syncFolderAndItemTypes() {
        val all = repository.allInventoryItems.first()
        if (all.isEmpty()) return
        val parentKeysWithChildren = all.map { it.parent }.toSet()
        all.forEach { item ->
            val shouldBeFolder = parentKeysWithChildren.contains(item.key)
            val targetType = if (shouldBeFolder) "folder" else "item"
            if (item.type != targetType) {
                repository.insertOrUpdateItem(item.copy(type = targetType))
            }
        }
    }

    fun showAlert(message: String, type: String = "info") {
        _uiState.update { it.copy(alertMessage = message, alertType = type) }
    }

    fun clearAlert() {
        _uiState.update { it.copy(alertMessage = null) }
    }

    fun setUserProfile(name: String) {
        val cleanName = name.trim().split(" ").joinToString(" ") { word ->
            word.lowercase().replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }
        val uid = "USER_${System.currentTimeMillis()}"
        _uiState.update {
            it.copy(userName = cleanName, userId = uid, isOnboarded = true)
        }
        showAlert("Welcome, $cleanName! 🚀", "success")
    }

    fun navigateFolder(key: String) {
        _uiState.update { state ->
            val newStack = if (state.pathStack.contains(key)) {
                val index = state.pathStack.indexOf(key)
                state.pathStack.subList(0, index + 1)
            } else {
                state.pathStack + key
            }
            state.copy(currentFolder = key, pathStack = newStack)
        }
    }

    fun jumpToBreadcrumb(index: Int) {
        _uiState.update { state ->
            if (index >= 0 && index < state.pathStack.size) {
                val newStack = state.pathStack.subList(0, index + 1)
                val targetKey = newStack.last()
                state.copy(currentFolder = targetKey, pathStack = newStack)
            } else state
        }
    }

    fun toggleCardSelection(key: String) {
        _uiState.update { state ->
            val newSet = state.selectedCardKeys.toMutableSet()
            if (newSet.contains(key)) {
                newSet.remove(key)
            } else {
                newSet.add(key)
            }
            val selectionActive = newSet.isNotEmpty()
            state.copy(selectedCardKeys = newSet, isSelectionMode = selectionActive)
        }
    }

    fun selectAllInCurrentFolder(currentItems: List<InventoryItemEntity>) {
        val keys = currentItems.map { it.key }.toSet()
        _uiState.update { it.copy(selectedCardKeys = keys, isSelectionMode = true) }
    }

    fun clearCardSelection() {
        _uiState.update { it.copy(selectedCardKeys = emptySet(), isSelectionMode = false, editTargetKey = null) }
    }

    fun addToCart(itemKey: String) {
        viewModelScope.launch {
            val item = repository.getItemByKey(itemKey) ?: return@launch
            val state = _uiState.value
            val rootFolder = if (itemKey.contains(">")) itemKey.split(">").first().trim() else "Home"
            val defaultUnit = item.allowedUnitsCsv.split(",").firstOrNull()?.trim() ?: "Box"

            val cartEntity = CartItemEntity(
                key = item.key,
                name = item.name,
                fullPath = item.key,
                rootFolder = rootFolder,
                quantity = 1,
                unit = defaultUnit,
                userId = state.userId
            )
            repository.insertOrUpdateCartItem(cartEntity)
            showAlert("✅ ${item.name} added to Bucket!", "success")
        }
    }

    fun updateCartQuantity(itemKey: String, change: Int) {
        viewModelScope.launch {
            val state = _uiState.value
            val current = cartItems.value.find { it.key == itemKey } ?: return@launch
            val newQty = current.quantity + change
            if (newQty <= 0) {
                repository.deleteCartItem(itemKey, state.userId)
                showAlert("Item removed from Bucket", "info")
            } else {
                repository.insertOrUpdateCartItem(current.copy(quantity = newQty))
            }
        }
    }

    fun setCartQuantityDirectly(itemKey: String, newQty: Int) {
        viewModelScope.launch {
            val state = _uiState.value
            val current = cartItems.value.find { it.key == itemKey } ?: return@launch
            if (newQty <= 0) {
                repository.deleteCartItem(itemKey, state.userId)
            } else {
                repository.insertOrUpdateCartItem(current.copy(quantity = newQty))
            }
        }
    }

    fun updateCartUnit(itemKey: String, newUnit: String) {
        viewModelScope.launch {
            val state = _uiState.value
            val current = cartItems.value.find { it.key == itemKey } ?: return@launch
            repository.insertOrUpdateCartItem(current.copy(unit = newUnit))
        }
    }

    fun removeFromCart(itemKey: String) {
        viewModelScope.launch {
            val state = _uiState.value
            repository.deleteCartItem(itemKey, state.userId)
            showAlert("Item removed from Bucket", "info")
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            val state = _uiState.value
            repository.clearCart(state.userId)
            showAlert("Bucket cleared!", "info")
        }
    }

    fun toggleFolderPrefix(itemKey: String, isChecked: Boolean) {
        viewModelScope.launch {
            val existing = repository.getItemByKey(itemKey) ?: return@launch
            repository.insertOrUpdateItem(existing.copy(toggleOn = isChecked))
        }
    }

    fun processBulkStructure(rawData: String) {
        viewModelScope.launch {
            val text = rawData.trim()
            if (text.isEmpty()) return@launch

            val state = _uiState.value
            if (state.editTargetKey != null) {
                // Edit mode
                val targetKey = state.editTargetKey
                val item = repository.getItemByKey(targetKey)
                if (item != null) {
                    val formattedName = text.split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
                    repository.insertOrUpdateItem(item.copy(name = formattedName, displayName = formattedName))
                    showAlert("Name updated! ✅", "success")
                }
                _uiState.update { it.copy(isAddModalOpen = false, editTargetKey = null, addModalTargetFolder = null) }
                clearCardSelection()
                return@launch
            }

            // Target folder to insert into (either explicitly clicked item/folder or current folder)
            val baseParent = state.addModalTargetFolder ?: state.currentFolder

            // Bulk import parsing
            val lines = text.split("\n", "\t").map { it.trim() }.filter { it.isNotEmpty() }
            lines.forEach { line ->
                val levels = line.split(">").map { lvl ->
                    lvl.trim().split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
                }
                var currentParent = baseParent

                levels.forEachIndexed { index, name ->
                    val isLast = index == levels.size - 1
                    val uniqueKey = if (currentParent == "root") name else "$currentParent>$name"
                    val existing = repository.getItemByKey(uniqueKey)

                    if (existing == null) {
                        val newItem = InventoryItemEntity(
                            key = uniqueKey,
                            name = name,
                            displayName = name,
                            type = if (isLast) "item" else "folder",
                            parent = currentParent
                        )
                        repository.insertOrUpdateItem(newItem)
                    }
                    currentParent = uniqueKey
                }
            }
            syncFolderAndItemTypes()
            showAlert("Structure updated successfully! 🚀", "success")
            _uiState.update { it.copy(isAddModalOpen = false, addModalTargetFolder = null) }
        }
    }

    fun bulkAddToCartSelected() {
        viewModelScope.launch {
            val keys = _uiState.value.selectedCardKeys
            val items = allInventoryItems.value.filter { keys.contains(it.key) && it.type == "item" }
            var count = 0
            val userId = _uiState.value.userId

            items.forEach { item ->
                val rootFolder = if (item.key.contains(">")) item.key.split(">").first().trim() else "Home"
                val defaultUnit = item.allowedUnitsCsv.split(",").firstOrNull()?.trim() ?: "Box"
                repository.insertOrUpdateCartItem(
                    CartItemEntity(
                        key = item.key,
                        name = item.name,
                        fullPath = item.key,
                        rootFolder = rootFolder,
                        quantity = 1,
                        unit = defaultUnit,
                        userId = userId
                    )
                )
                count++
            }
            showAlert("✅ $count items added to Bucket!", "success")
            clearCardSelection()
        }
    }

    fun bulkDeleteSelected() {
        viewModelScope.launch {
            val keys = _uiState.value.selectedCardKeys
            val userId = _uiState.value.userId
            keys.forEach { key ->
                repository.deleteItemAndChildren(key)
                repository.deleteCartItemsByKeys(key, rootFolder = key, userId = userId)
            }
            syncFolderAndItemTypes()
            showAlert("Selected items deleted! 🗑️", "success")
            clearCardSelection()
        }
    }

    fun addCustomUnitToCategoryTree(categoryKey: String, unitName: String) {
        viewModelScope.launch {
            val formatted = unitName.trim().replaceFirstChar { it.uppercase() }
            if (formatted.isEmpty()) return@launch

            val rootParent = if (categoryKey.contains(">")) categoryKey.split(">").first().trim() else categoryKey
            val all = allInventoryItems.value

            all.forEach { item ->
                if (item.key == rootParent || item.key.startsWith("$rootParent>")) {
                    val units = item.allowedUnitsCsv.split(",").map { it.trim() }.toMutableList()
                    if (!units.contains(formatted)) {
                        units.add(formatted)
                        val newCsv = units.joinToString(",")
                        repository.insertOrUpdateItem(item.copy(allowedUnitsCsv = newCsv, currentUnit = formatted))
                    }
                }
            }
            showAlert("Unit '$formatted' added to category tree! ✅", "success")
        }
    }

    fun deleteCustomUnitFromCategoryTree(categoryKey: String, unitToDelete: String) {
        viewModelScope.launch {
            val rootParent = if (categoryKey.contains(">")) categoryKey.split(">").first().trim() else categoryKey
            val all = allInventoryItems.value

            all.forEach { item ->
                if (item.key == rootParent || item.key.startsWith("$rootParent>")) {
                    val units = item.allowedUnitsCsv.split(",").map { it.trim() }.filter { it != unitToDelete }
                    val newCsv = if (units.isEmpty()) "Box" else units.joinToString(",")
                    val newUnit = if (units.isEmpty()) "Box" else units.first()
                    repository.insertOrUpdateItem(item.copy(allowedUnitsCsv = newCsv, currentUnit = newUnit))
                }
            }
            showAlert("Unit '$unitToDelete' deleted 🗑️", "info")
        }
    }

    fun validateAdminPin(pin: String): Boolean {
        return if (pin == _uiState.value.adminPin) {
            _uiState.update { it.copy(isAdminMode = true, isAdminGatewayOpen = false) }
            showAlert("Access Granted! Admin Portal Active. 🚀", "success")
            true
        } else {
            showAlert("🚫 INVALID PIN! Access Denied.", "error")
            false
        }
    }

    fun updateAdminPassword(oldPin: String, newPin: String) {
        if (oldPin != _uiState.value.adminPin) {
            showAlert("🚫 Purana (Old) PIN galat hai!", "error")
            return
        }
        if (newPin.length < 4) {
            showAlert("⚠️ New PIN must be at least 4 digits!", "error")
            return
        }
        _uiState.update { it.copy(adminPin = newPin, isAdminSettingsOpen = false) }
        showAlert("🎉 Master PIN updated successfully!", "success")
    }

    fun sendBroadcastNotification(message: String) {
        if (message.trim().isEmpty()) {
            showAlert("Message empty hai! ✍️", "error")
            return
        }
        _uiState.update { it.copy(broadcastMessage = message.trim(), isAdminSettingsOpen = false) }
        showAlert("Broadcast message sent to all users! 📢", "success")
    }

    fun logoutAdmin() {
        _uiState.update { it.copy(isAdminMode = false, isAdminSettingsOpen = false) }
        showAlert("Logged out from Admin mode 🔒", "info")
    }

    fun setAddModalOpen(open: Boolean, editKey: String? = null, targetFolder: String? = null) {
        _uiState.update { it.copy(isAddModalOpen = open, editTargetKey = editKey, addModalTargetFolder = targetFolder) }
    }

    fun openAddSubItemModal(targetParentKey: String) {
        _uiState.update { it.copy(isAddModalOpen = true, addModalTargetFolder = targetParentKey, editTargetKey = null) }
    }

    fun setSearchOpen(open: Boolean) {
        _uiState.update { it.copy(isSearchOpen = open) }
    }

    fun setCartOpen(open: Boolean) {
        _uiState.update { it.copy(isCartOpen = open) }
    }

    fun setAdminSettingsOpen(open: Boolean) {
        _uiState.update { it.copy(isAdminSettingsOpen = open) }
    }

    fun setShareAppOpen(open: Boolean) {
        _uiState.update { it.copy(isShareAppOpen = open) }
    }

    fun setAdminGatewayOpen(open: Boolean) {
        _uiState.update { it.copy(isAdminGatewayOpen = open) }
    }

    fun setOrderSlipOpen(open: Boolean) {
        _uiState.update { it.copy(isOrderSlipOpen = open) }
    }

    fun handleVoiceCommand(rawTranscript: String) {
        val transcript = rawTranscript.trim().lowercase()
        if (transcript == "admin.html") {
            setSearchOpen(false)
            setAdminGatewayOpen(true)
            return
        }
        if (transcript.startsWith("open ")) {
            val folderName = transcript.substringAfter("open ").trim()
            val match = allInventoryItems.value.find { it.name.lowercase() == folderName }
            if (match != null) {
                navigateFolder(match.key)
                setSearchOpen(false)
                showAlert("Opening folder: ${match.name} 📁", "success")
            } else {
                showAlert("Folder '$folderName' not found!", "error")
            }
            return
        }
        if (transcript.startsWith("add ")) {
            val phrase = transcript.substringAfter("add ").replace("to cart", "").trim()
            val firstWord = phrase.split(" ").firstOrNull() ?: ""
            var qty = 1
            var itemName = phrase
            if (firstWord.toIntOrNull() != null) {
                qty = firstWord.toInt()
                itemName = phrase.substringAfter(firstWord).trim()
            }
            val match = allInventoryItems.value.find { it.name.lowercase() == itemName }
            if (match != null) {
                viewModelScope.launch {
                    val state = _uiState.value
                    val rootFolder = if (match.key.contains(">")) match.key.split(">").first().trim() else "Home"
                    val defaultUnit = match.allowedUnitsCsv.split(",").firstOrNull()?.trim() ?: "Box"
                    repository.insertOrUpdateCartItem(
                        CartItemEntity(
                            key = match.key,
                            name = match.name,
                            fullPath = match.key,
                            rootFolder = rootFolder,
                            quantity = qty,
                            unit = defaultUnit,
                            userId = state.userId
                        )
                    )
                    setSearchOpen(false)
                    showAlert("✅ Added $qty ${match.name} to Bucket!", "success")
                }
            } else {
                showAlert("Item '$itemName' not found!", "error")
            }
            return
        }
    }
}
