package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class WayStockRepository(context: Context) {
    private val db = WayStockDatabase.getDatabase(context)
    private val dao = db.inventoryDao()

    val allInventoryItems: Flow<List<InventoryItemEntity>> = dao.getAllInventoryItemsFlow()

    fun getInventoryItemsByParent(parentKey: String): Flow<List<InventoryItemEntity>> {
        return dao.getInventoryItemsByParent(parentKey)
    }

    fun getCartItems(userId: String): Flow<List<CartItemEntity>> {
        return dao.getCartItemsFlow(userId)
    }

    fun getSearchHistory(userId: String): Flow<List<SearchHistoryEntity>> {
        return dao.getSearchHistoryFlow(userId)
    }

    suspend fun seedInitialDataIfEmpty() {
        val existing = dao.getAllInventoryItemsFlow().first()
        if (existing.isEmpty()) {
            val defaultItems = listOf(
                // Folders at Root
                InventoryItemEntity(key = "Snacks", name = "Snacks", displayName = "Snacks", type = "folder", parent = "root"),
                InventoryItemEntity(key = "Paan Masala", name = "Paan Masala", displayName = "Paan Masala", type = "folder", parent = "root"),
                InventoryItemEntity(key = "Cigarettes", name = "Cigarettes", displayName = "Cigarettes", type = "folder", parent = "root"),
                InventoryItemEntity(key = "Perfumes", name = "Perfumes", displayName = "Perfumes", type = "folder", parent = "root"),
                InventoryItemEntity(key = "Beverages", name = "Beverages", displayName = "Beverages", type = "folder", parent = "root"),

                // Snacks sub-items & folders
                InventoryItemEntity(key = "Snacks>Lays", name = "Lays", displayName = "Lays", type = "folder", parent = "Snacks"),
                InventoryItemEntity(key = "Snacks>Bingo", name = "Bingo", displayName = "Bingo", type = "item", parent = "Snacks", allowedUnitsCsv = "Box,Packet,Carton"),
                InventoryItemEntity(key = "Snacks>Pringles", name = "Pringles", displayName = "Pringles", type = "item", parent = "Snacks", allowedUnitsCsv = "Can,Box,Tray"),

                // Snacks > Lays sub-items
                InventoryItemEntity(key = "Snacks>Lays>Magic Masala", name = "Magic Masala", displayName = "Magic Masala", type = "item", parent = "Snacks>Lays", allowedUnitsCsv = "Box,Packet"),
                InventoryItemEntity(key = "Snacks>Lays>Cream & Onion", name = "Cream & Onion", displayName = "Cream & Onion", type = "item", parent = "Snacks>Lays", allowedUnitsCsv = "Box,Packet"),
                InventoryItemEntity(key = "Snacks>Lays>Classic Salted", name = "Classic Salted", displayName = "Classic Salted", type = "item", parent = "Snacks>Lays", allowedUnitsCsv = "Box,Packet"),

                // Paan Masala sub-items
                InventoryItemEntity(key = "Paan Masala>Vimal", name = "Vimal", displayName = "Vimal", type = "item", parent = "Paan Masala", allowedUnitsCsv = "Pouch,Box,Packet"),
                InventoryItemEntity(key = "Paan Masala>Rajnigandha", name = "Rajnigandha", displayName = "Rajnigandha", type = "item", parent = "Paan Masala", allowedUnitsCsv = "Can,Box,Pouch"),

                // Cigarettes sub-items
                InventoryItemEntity(key = "Cigarettes>Gold Flake", name = "Gold Flake", displayName = "Gold Flake", type = "item", parent = "Cigarettes", allowedUnitsCsv = "Packet,Carton,Box"),
                InventoryItemEntity(key = "Cigarettes>Marlboro", name = "Marlboro", displayName = "Marlboro", type = "item", parent = "Cigarettes", allowedUnitsCsv = "Packet,Carton,Box"),

                // Perfumes sub-items
                InventoryItemEntity(key = "Perfumes>Fogg", name = "Fogg", displayName = "Fogg", type = "item", parent = "Perfumes", allowedUnitsCsv = "Bottle,Box,Tray"),
                InventoryItemEntity(key = "Perfumes>Wild Stone", name = "Wild Stone", displayName = "Wild Stone", type = "item", parent = "Perfumes", allowedUnitsCsv = "Bottle,Box"),

                // Beverages sub-items
                InventoryItemEntity(key = "Beverages>Coca Cola", name = "Coca Cola", displayName = "Coca Cola", type = "item", parent = "Beverages", allowedUnitsCsv = "Bottle,Can,Crate"),
                InventoryItemEntity(key = "Beverages>Red Bull", name = "Red Bull", displayName = "Red Bull", type = "item", parent = "Beverages", allowedUnitsCsv = "Can,Tray,Box")
            )
            dao.insertAllItems(defaultItems)
        }
    }

    suspend fun insertOrUpdateItem(item: InventoryItemEntity) = dao.insertOrUpdateItem(item)

    suspend fun deleteItemAndChildren(key: String) = dao.deleteItemAndChildren(key)

    suspend fun searchInventory(query: String) = dao.searchInventory(query)

    suspend fun insertOrUpdateCartItem(item: CartItemEntity) = dao.insertOrUpdateCartItem(item)

    suspend fun deleteCartItem(key: String, userId: String) = dao.deleteCartItem(key, userId)

    suspend fun deleteCartItemsByKeys(key: String, rootFolder: String, userId: String) = dao.deleteCartItemsByKeys(key, rootFolder, userId)

    suspend fun clearCart(userId: String) = dao.clearCart(userId)

    suspend fun addSearchHistory(entry: SearchHistoryEntity) = dao.insertSearchHistory(entry)

    suspend fun getItemByKey(key: String): InventoryItemEntity? = dao.getItemByKey(key)
}
