package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface InventoryDao {
    @Query("SELECT * FROM inventory_items")
    fun getAllInventoryItemsFlow(): Flow<List<InventoryItemEntity>>

    @Query("SELECT * FROM inventory_items WHERE parent = :parentKey")
    fun getInventoryItemsByParent(parentKey: String): Flow<List<InventoryItemEntity>>

    @Query("SELECT * FROM inventory_items WHERE key = :key LIMIT 1")
    suspend fun getItemByKey(key: String): InventoryItemEntity?

    @Query("SELECT * FROM inventory_items WHERE LOWER(name) LIKE '%' || LOWER(:query) || '%' OR LOWER(key) LIKE '%' || LOWER(:query) || '%' LIMIT 10")
    suspend fun searchInventory(query: String): List<InventoryItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateItem(item: InventoryItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllItems(items: List<InventoryItemEntity>)

    @Query("DELETE FROM inventory_items WHERE key = :key OR key LIKE :key || '>%'")
    suspend fun deleteItemAndChildren(key: String)

    @Query("DELETE FROM inventory_items")
    suspend fun clearInventory()

    // Cart Queries
    @Query("SELECT * FROM cart_items WHERE userId = :userId")
    fun getCartItemsFlow(userId: String): Flow<List<CartItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateCartItem(item: CartItemEntity)

    @Query("DELETE FROM cart_items WHERE `key` = :key AND userId = :userId")
    suspend fun deleteCartItem(key: String, userId: String)

    @Query("DELETE FROM cart_items WHERE userId = :userId AND (`key` = :key OR `key` LIKE :key || '>%' OR rootFolder = :rootFolder)")
    suspend fun deleteCartItemsByKeys(key: String, rootFolder: String, userId: String)

    @Query("DELETE FROM cart_items WHERE userId = :userId")
    suspend fun clearCart(userId: String)

    // Search History Queries
    @Query("SELECT * FROM search_history WHERE userId = :userId ORDER BY timestamp DESC LIMIT 10")
    fun getSearchHistoryFlow(userId: String): Flow<List<SearchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSearchHistory(entry: SearchHistoryEntity)
}
